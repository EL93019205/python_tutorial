from setuptools import setup

setup(
    name='python_tutorial',
    version='',
    packages=[''],
    url='https://github.com/EL93019205',
    license='free',
    author='jun',
    author_email='',
    description=''
)
